package ServletBanking;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.training.OnlineBanking.dao.customer;
import com.inautix.training.OnlineBanking.domain.atmApplydomain;

/**
 * Servlet implementation class atmApply
 */
@WebServlet("/atmApply")
public class atmApply extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public atmApply() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		atmApplydomain aad=new atmApplydomain();
		HttpSession session=request.getSession();
		aad.setUsed_id((String)session.getAttribute("name"));
		aad.setCard_type(request.getParameter("card_type"));
		aad.setDoor_no(request.getParameter("door_no"));
		aad.setStreet(request.getParameter("street"));
		aad.setArea(request.getParameter("area"));
		aad.setCity(request.getParameter("city"));
		aad.setState(request.getParameter("state"));
		aad.setAdhaar(request.getParameter("adhaar"));
		customer cudao=new customer();
		cudao.applyatm(aad);
		RequestDispatcher rd = request.getRequestDispatcher("/CustomerPage.html");
		rd.forward(request, response);
		
	}

}
