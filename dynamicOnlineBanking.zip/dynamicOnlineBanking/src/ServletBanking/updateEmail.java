package ServletBanking;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.training.OnlineBanking.controller.admincontorller;

/**
 * Servlet implementation class updateEmail
 */
@WebServlet("/updateEmail")
public class updateEmail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public updateEmail() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String userId=(String)session.getAttribute("name");
		String mail=request.getParameter("mail");
		System.out.println(userId+""+mail);
		admincontorller ad=new admincontorller();
		ad.updateEmail(mail,userId);
		RequestDispatcher rd = request.getRequestDispatcher("/CustomerPage.html");
		rd.forward(request, response);
	}

}
