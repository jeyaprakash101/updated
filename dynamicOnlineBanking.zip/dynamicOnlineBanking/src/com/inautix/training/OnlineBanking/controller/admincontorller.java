package com.inautix.training.OnlineBanking.controller;

import java.util.List;

import com.inautix.training.OnlineBanking.dao.admin;

public class admincontorller {
	public void updateEmail(String cus_Email,String cus_Id)
	{
		admin dao=new admin();
		System.out.println("Inside Admin controller");
		dao.updateEmail(cus_Email,cus_Id);
		
	}

}
