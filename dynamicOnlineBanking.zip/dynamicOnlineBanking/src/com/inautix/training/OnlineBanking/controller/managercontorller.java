package com.inautix.training.OnlineBanking.controller;

import java.util.List;

import com.inautix.training.OnlineBanking.dao.manager;

public class managercontorller {
	public List getAllCustomers(){
		List CustomerList = null;
		
		manager Dao = new manager();
		CustomerList = Dao.getAllCustomer();
		return CustomerList;
	}
}
