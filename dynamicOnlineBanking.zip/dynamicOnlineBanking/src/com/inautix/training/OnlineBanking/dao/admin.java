package com.inautix.training.OnlineBanking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.training.OnlineBanking.domain.account;

public class admin {
public void updateEmail(String cus_Email,String cus_id)
{
	Connection con=null;
	List customerList = new ArrayList();
	account man = null;
	System.out.println("Inside Dao class");
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	}catch(ClassNotFoundException e) {
		System.out.println(e);
	}

	try {
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
System.out.println("Inside dao Try block ");
		Statement stmt = con.createStatement();
		
		String st="update cusdetails_xbbnhg4 set cus_emailid='"+cus_Email+"'where cus_id='"+cus_id+"'";
				stmt.execute(st);
				System.out.println("Your information has been updated");
				
	
	 }
	catch(Exception e){
		
		
	}
	finally{
		try{
			
			con.close();
		}catch(Exception e){
			
		}
	}
		
}

public int transfer(String youid, String cusid, int amount) {
	int balanceyou=0;
	Connection con=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	}catch(ClassNotFoundException e) {
		System.out.println(e);
	}

	try {
		con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

		Statement stmt = con.createStatement();
		System.out.println(youid+""+cusid+""+amount);
		

		
		ResultSet rs1 =stmt.executeQuery("select  cus_balance from cusbalance_xbbnhg4 where cus_id='"+youid+"'");
		while(rs1.next()) {
			balanceyou=rs1.getInt("cus_balance");
		
		}
		System.out.println(balanceyou);
		balanceyou=balanceyou-amount;
		
		stmt.execute("update cusbalance_xbbnhg4 set cus_balance="+balanceyou+"where cus_id='"+youid+"'");
		stmt.execute("update cusbalance_xbbnhg4 set cus_balance=cus_balance+"+amount+"where cus_id='"+cusid+"'");
		System.out.println("your transcation have been succesfully completed");
	return balanceyou;
	 }
	catch(Exception e){
		
		
	}
	finally{
		try{
			
			con.close();
		}catch(Exception e){
			
		}
	}
	return 0;	
}


}
