package com.inautix.training.OnlineBanking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.training.OnlineBanking.domain.account;
import com.inautix.training.OnlineBanking.domain.atmApplydomain;

public class customer 
{
	public  void createCustomer(account acc) throws SQLException
	{
		
		try {
			System.out.println("Inside try of class");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		Connection con=null;
		try 
{
			
con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
Statement stmt = con.createStatement();		
System.out.println("Inside DAO");
String sql="insert into cusdetails_xbbnhg4 values('"+acc.getA_Id()+"','"+acc.getName()+"','"+acc.getPan()+"','"+acc.getEmailID()+"')";
stmt.execute(sql);
String sql1="insert into accountlogin_xbbnhg4 values('"+acc.getA_Id()+"','"+acc.getPassword()+"')";
stmt.execute(sql1);
System.out.println("Record successfuly inserted ");
con.commit();
con.close();

}
		catch(SQLException e) {
			System.out.println(e);
			System.out.println(e.getMessage());
			System.out.println(e.getSQLState());
			System.out.println(e.getErrorCode());
			e = e.getNextException();
	}
		finally
		{
			System.out.println("inside dao finally block");
			con.close();
			
		}
	}
	public List getAccountDetailsForCustomer(String customerId)
	{
		List l=new ArrayList();
		Connection con=null;
		 
		
	try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	}catch(ClassNotFoundException e) {
	System.out.println(e);
		}

	try {
	 con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

	Statement stmt = con.createStatement();
	String sql = "select * from cusdetails_xbbnhg4 where cus_id='"+customerId+"'";
	System.out.println("SQL "+sql);
	ResultSet rs = stmt.executeQuery(sql);
				
		 
	while(rs.next()) {
		
		  account  acc = new account();
			System.out.println("inside while loop");
			acc.setA_Id(rs.getString("cus_id"));
			acc.setName(rs.getString("cus_name"));
			acc. setPan(rs.getString("cus_pan"));
			acc. setEmailID(rs.getString("cus_emailid"));
			l.add(acc);
	}

	 }
	catch(Exception e){
		
		
	}/*finally{
		try{
			
			con.close();
		}catch(Exception e){
			
		}
	}*/


	return  l;
	}
	public int getbalance(String youid) {
		Connection con=null;
		 
		int b=0;
		try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
		System.out.println(e);
			}

		try {
			
		 con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

		Statement stmt = con.createStatement();
		String sql = "select cus_balance from cusbalance_xbbnhg4 where cus_id='"+youid+"'";
		
		ResultSet j = stmt.executeQuery(sql);
					while(j.next())
					{
						 b= j.getInt("cus_balance");
					}
			 

		 }
		catch(Exception e){
			
			
		}
		return b;
	}
	public void applyatm(atmApplydomain aad) {
		Connection con=null;
		 
	
		try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
		System.out.println(e);
			}

		try {
			
		 con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

		Statement stmt = con.createStatement();
		String sql = "insert into atmapply_xbbnhg4 values('"+aad.getUsed_id()+"','"+aad.getDoor_no()+"','"+aad.getStreet()+"','"+aad.getArea()+"','"+aad.getCity()+"','"+aad.getState()+"','"+aad.getAdhaar()+"')";
		
		 stmt.execute(sql);
					
			 System.out.println("Successfully Applied for atm");

		 }
		catch(Exception e){
			
			
		}
		
	}
	

	
	
}
