package com.inautix.training.OnlineBanking.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
public class loginValidation {

	public boolean login(String id,String pass)
	{
		String dbPass="";
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}
		try {
			
			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();
			
					ResultSet rs =stmt.executeQuery("select A_password from accountlogin_xbbnhg4 where A_id='"+id+"'");
					
			while(rs.next()) 
			{
				dbPass=rs.getString("A_password");
			}
		 }
		catch(Exception e){
			
			
		}
		System.out.println("outside trty block and retrived password is "+dbPass);
		if(dbPass.equals(pass))
		{
		return true;
		}
		else
			return false;
	}
}
