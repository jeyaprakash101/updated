package com.inautix.training.OnlineBanking.domain;

public class atmApplydomain {
private String card_type="",door_no="",street="",area="",city="",state="",Adhaar="",used_id="";

public String getUsed_id() {
	return used_id;
}

public void setUsed_id(String used_id) {
	this.used_id = used_id;
}

public void setCard_type(String card_type) {
	this.card_type = card_type;
}

public void setDoor_no(String door_no) {
	this.door_no = door_no;
}

public void setStreet(String street) {
	this.street = street;
}

public void setArea(String area) {
	this.area = area;
}

public void setCity(String city) {
	this.city = city;
}

public void setState(String state) {
	this.state = state;
}

public void setAdhaar(String adhaar) {
	Adhaar = adhaar;
}

public String getCard_type() {
	return card_type;
}

public String getDoor_no() {
	return door_no;
}

public String getStreet() {
	return street;
}

public String getArea() {
	return area;
}

public String getCity() {
	return city;
}

public String getState() {
	return state;
}

public String getAdhaar() {
	return Adhaar;
}
}
