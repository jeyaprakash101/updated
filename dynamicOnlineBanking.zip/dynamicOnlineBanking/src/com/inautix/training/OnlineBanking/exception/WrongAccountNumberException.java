package com.inautix.training.OnlineBanking.exception;

public class WrongAccountNumberException extends Exception
{
public String toString()
{
	return "It seems you have entered wrong Account Number";
}
}
